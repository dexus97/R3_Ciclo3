package com.usa.ciclo3.r3.crudrepository;

import com.usa.ciclo3.r3.model.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category, Integer> {
}
